﻿using BDLO.Controllers;
using System;

namespace BDLO
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("1. Film");
            Console.WriteLine("2. FilmDemonstration");
            Console.WriteLine("3. FilmProducer");
            Console.WriteLine("4. Producer");
            Console.WriteLine("5. Ticket");
            Console.WriteLine("6. Viewer");
            Console.WriteLine("Введите номер таблицы:");
            int table = Int32.Parse(Console.ReadLine());
            Console.WriteLine();
            Console.WriteLine("1. Создать запись");
            Console.WriteLine("2. Прочитать все записи");
            Console.WriteLine("3. Обновить запись");
            Console.WriteLine("4. Удалить запись");
            Console.WriteLine("5. Сгенерировать случайные записи");
            Console.WriteLine("6. Найти запись");
            Console.WriteLine("Введите номер действия:");
            int action = Int32.Parse(Console.ReadLine());

            BaseController controller = null;

            switch (table)
            {
                case 1:
                    controller = new FilmController();
                    break;
                case 2:
                    controller = new FilmDemonstrationController();
                    break;
                case 3:
                    controller = new FilmProducerController();
                    break;
                case 4:
                    controller = new ProducerController();
                    break;
                case 5:
                    controller = new TicketController();
                    break;
                case 6:
                    controller = new ViewerController();
                    break;
            }


            switch (action)
            {
                case 1:
                    controller.Create();
                    break;
                case 2:
                    controller.Read();
                    break;
                case 3:
                    controller.Update();
                    break;
                case 4:
                    controller.Delete();
                    break;
                case 5:
                    controller.Find();
                    break;
            }
        }
    }
}
