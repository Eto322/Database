﻿using BDLO.Models;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Text;

namespace BDLO.Controllers
{
    public class FilmDemonstrationController : BaseController
    {
        public override void Read()
        {
            Console.Clear();
            try
            {

                foreach (var i in context.film_demonstration)
                {
                    Console.WriteLine("Id: {0}", i.id);
                    Console.WriteLine("Date: {0}", i.date);
                    Console.WriteLine();
                }
                Console.WriteLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadLine();
            }
            Console.ReadLine();
        }

        public override void Create()
        {
            var entity = new FilmDemonstration();

            Console.Clear();
            Console.WriteLine("Создайте новый FilmDemonstration:");
            Console.WriteLine("Date:");
            Console.WriteLine("Year:");
            int year = Int32.Parse(Console.ReadLine());
            Console.WriteLine("Month:");
            int month = Int32.Parse(Console.ReadLine());
            Console.WriteLine("Day:");
            int day = Int32.Parse(Console.ReadLine());
            entity.date = new DateTime(year, month, day);

            try
            {
                context.film_demonstration.Add(entity);
                context.SaveChanges();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadLine();
            }

        }

        public override void Delete()
        {
            base.Delete();
            var entity = context.film_demonstration.Find(base.deleteId);
            context.film_demonstration.Remove(entity);
            context.SaveChanges();
        }
        public override void Update()
        {
            base.Update();
            var entity = context.film_demonstration.Find(base.updateId);
            context.film_demonstration.Update(entity);
            context.SaveChanges();
        }
        public override void Find()
        {
            base.Find();
            var i = context.film_demonstration.Find(base.findId);
            Console.WriteLine("Id: {0}", i.id);
            Console.WriteLine("Date: {0}", i.date);
            Console.WriteLine();

        }
    }
}
