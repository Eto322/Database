﻿using BDLO.Models;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Text;

namespace BDLO.Controllers
{
    public class FilmProducerController : BaseController
    {
        public override void Read()
        {
            Console.Clear();
            try
            {

                foreach (var i in context.film_producer)
                {
                    Console.WriteLine("Id: {0}", i.id);
                    Console.WriteLine("Producer_id: {0}", i.producer_id);
                    Console.WriteLine("Film_id{0}", i.film_id);
                    Console.WriteLine();
                }
                Console.WriteLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadLine();
            }
            Console.ReadLine();
        }

        public override void Create()
        {
            var entity = new FilmProducer();

            Console.Clear();
            Console.WriteLine("Создайте новый FilmProducer:");
            Console.WriteLine("ProducerId:");
            entity.producer_id = Int32.Parse(Console.ReadLine());
            Console.WriteLine("Film_id:");
            entity.film_id = Int32.Parse(Console.ReadLine());

            try
            {
                context.film_producer.Add(entity);
                context.SaveChanges();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadLine();
            }

        }

        public override void Delete()
        {
            base.Delete();
            var entity = context.film_producer.Find(base.deleteId);
            context.film_producer.Remove(entity);
            context.SaveChanges();
        }
        public override void Update()
        {
            base.Update();
            var entity = context.film_producer.Find(base.updateId);
            context.film_producer.Update(entity);
            context.SaveChanges();
        }
        public override void Find()
        {
            base.Find();
            var i = context.film_producer.Find(base.findId);
            Console.WriteLine("Id: {0}", i.id);
            Console.WriteLine("Producer_id: {0}", i.producer_id);
            Console.WriteLine("Film_id{0}", i.film_id);
            Console.WriteLine();

        }
    }
}
