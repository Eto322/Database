﻿using BDLO.Models;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Text;

namespace BDLO.Controllers
{
    public class ProducerController : BaseController
    {
        public override void Read()
        {
            Console.Clear();
            try
            {

                foreach (var i in context.producer)
                {
                    Console.WriteLine("Id: {0}", i.id);
                    Console.WriteLine("Name: {0}", i.name);
                    Console.WriteLine("Surname{0}", i.surname);
                    Console.WriteLine();
                }
                Console.WriteLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadLine();
            }
            Console.ReadLine();
        }

        public override void Create()
        {
            var entity = new Producer();

            Console.Clear();
            Console.WriteLine("Создайте новый Producer:");
            Console.WriteLine("name:");
            entity.name = Console.ReadLine();
            Console.WriteLine("surname:");
            entity.surname = Console.ReadLine();

            try
            {
                context.producer.Add(entity);
                context.SaveChanges();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadLine();
            }

        }

        public override void Delete()
        {
            base.Delete();
            var entity = context.producer.Find(base.deleteId);
            context.producer.Remove(entity);
            context.SaveChanges();
        }
        public override void Update()
        {
            base.Update();
            var entity = context.producer.Find(base.updateId);
            context.producer.Update(entity);
            context.SaveChanges();
        }
        public override void Find()
        {
            base.Find();
            var i = context.producer.Find(base.findId);
            Console.WriteLine("Id: {0}", i.id);
            Console.WriteLine("Name: {0}", i.name);
            Console.WriteLine("Surname{0}", i.surname);
            Console.WriteLine();

        }
    }
}
