﻿using BDLO.Models;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Text;

namespace BDLO.Controllers
{
    public class FilmController : BaseController
    {
        public override void Read()
        {
            Console.Clear();
            try
            {

                foreach (var i in context.film)
                {
                    Console.WriteLine("Id: {0}", i.id);
                    Console.WriteLine("Title: {0}", i.title);
                    Console.WriteLine("Age limit: {0}", i.age_limit);
                    Console.WriteLine("Film demonstration id: {0}", i.film_demonstration_id);
                    Console.WriteLine();
                }
                Console.WriteLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadLine();
            }
            Console.ReadLine();
        }

        public override void Create()
        {
            var film = new Film();

            Console.Clear();
            Console.WriteLine("Создайте новый Film:");
            Console.WriteLine("Title:");
            film.title = Console.ReadLine();
            Console.WriteLine("Age limit");
            film.age_limit = Int32.Parse(Console.ReadLine());
            Console.WriteLine("Film demonstration id:");
            film.film_demonstration_id = Int32.Parse(Console.ReadLine());

            try
            {
                context.film.Add(film);
                context.SaveChanges();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadLine();
            }

        }

        public override void Delete()
        {
            base.Delete();
            var entity = context.film.Find(base.deleteId);
            context.film.Remove(entity);
            context.SaveChanges();
        }
        public override void Update()
        {
            base.Update();
            var entity = context.film.Find(base.updateId);
            context.film.Update(entity);
            context.SaveChanges();
        }
        public override void Find()
        {
            base.Find();
            var i = context.film.Find(base.findId);
            Console.WriteLine("Id: {0}", i.id);
            Console.WriteLine("Title: {0}", i.title);
            Console.WriteLine("Age limit: {0}", i.age_limit);
            Console.WriteLine("Film demonstration id: {0}", i.film_demonstration_id);
            Console.WriteLine();

        }
    }
}
