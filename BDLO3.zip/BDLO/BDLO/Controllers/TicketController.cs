﻿using BDLO.Models;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Text;

namespace BDLO.Controllers
{
    public class TicketController : BaseController
    {
        public override void Read()
        {
            Console.Clear();
            try
            {

                foreach (var i in context.ticket)
                {
                    Console.WriteLine("Id: {0}", i.id);
                    Console.WriteLine("Price: {0}", i.price);
                    Console.WriteLine("Seat{0}", i.seat);
                    Console.WriteLine("Film demonstration id{0}", i.film_demonstration_id);
                    Console.WriteLine();
                }
                Console.WriteLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadLine();
            }
            Console.ReadLine();
        }

        public override void Create()
        {
            var entity = new Ticket();

            Console.Clear();
            Console.WriteLine("Создайте новый Ticket:");
            Console.WriteLine("Price:");
            entity.price = Decimal.Parse(Console.ReadLine());
            Console.WriteLine("Seat:");
            entity.seat = Int32.Parse(Console.ReadLine());
            Console.WriteLine("Film demonstration id");
            entity.film_demonstration_id = Int32.Parse(Console.ReadLine());

            try
            {
                context.ticket.Add(entity);
                context.SaveChanges();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadLine();
            }

        }

        public override void Delete()
        {
            base.Delete();
            var entity = context.ticket.Find(base.deleteId);
            context.ticket.Remove(entity);
            context.SaveChanges();
        }
        public override void Update()
        {
            base.Update();
            var entity = context.ticket.Find(base.updateId);
            context.ticket.Update(entity);
            context.SaveChanges();
        }
        public override void Find()
        {
            base.Find();
            var i = context.ticket.Find(base.findId);
            Console.WriteLine("Id: {0}", i.id);
            Console.WriteLine("Price: {0}", i.price);
            Console.WriteLine("Seat{0}", i.seat);
            Console.WriteLine("Film demonstration id{0}", i.film_demonstration_id);
            Console.WriteLine();

        }
    }
}
