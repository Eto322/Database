﻿using BDLO.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace BDLO
{
    public class Context : DbContext
    {
        public DbSet<Film> film { get; set; }
        public DbSet<FilmDemonstration> film_demonstration { get; set; }
        public DbSet<FilmProducer> film_producer { get; set; }
        public DbSet<Producer> producer { get; set; }
        public DbSet<Ticket> ticket { get; set; }
        public DbSet<Viewer> viewer { get; set; }

        public Context()
        {
            Database.EnsureCreated();
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseNpgsql("Host=localhost;Username=postgres;Password=p;Database=bdlo3");
        }
    }
}
