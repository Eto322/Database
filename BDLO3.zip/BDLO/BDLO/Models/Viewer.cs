﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BDLO.Models
{
    public class Viewer
    {
        public int id { get; set; }
        public string name { get; set; }
        public string surname { get; set; }
        public DateTime date_of_birth { get; set; }
        public int ticker_id { get; set; }
        public Ticket ticket { get; set; }
    }
}
