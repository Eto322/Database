﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BDLO.Models
{
    public class Ticket
    {
        public int id { get; set; }
        public decimal price { get; set; }
        public int seat { get; set; }
        public int film_demonstration_id { get; set; }
        public FilmDemonstration film_demonstration { get; set; }
    }
}
