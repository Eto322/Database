﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BDLO.Models
{
    public class Producer
    {
        public int id { get; set; }
        public string name { get; set; }
        public string surname { get; set; }
    }
}
