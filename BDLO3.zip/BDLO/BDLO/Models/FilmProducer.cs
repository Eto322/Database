﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BDLO.Models
{
    public class FilmProducer
    {
        public int id { get; set; }
        public int producer_id { get; set; }
        public Producer producer { get; set; }
        public int film_id { get; set; }
        public Film film { get; set; }
    }
}
