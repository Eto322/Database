﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BDLO.Models
{
    public class FilmDemonstration
    {
        public int id { get; set; }
        public DateTime date { get; set; }
    }
}
