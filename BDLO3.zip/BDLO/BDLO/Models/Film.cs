﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BDLO.Models
{
    public class Film
    {
        public int id { get; set; }
        public string title { get; set; }
        public int age_limit { get; set; }
        public int film_demonstration_id { get; set; }
        public FilmDemonstration film_demonstration { get; set; }
    }
}
